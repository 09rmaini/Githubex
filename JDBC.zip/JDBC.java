
import java.awt.Button;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;
public class JDBC implements ActionListener {

	Button j,k,g,h,i,k1,k2,k3,k4;
	JFrame f,f1,f2,f3,f4;
	JTextField T1, T2, T3,T4, T5, T6,T7, T8, T9,T10;
	Label L1, L2, L3,L4, L5, L6,L7, L8, L9,L10;
	
	public static void main(String[] args) {
	

		JDBC x = new JDBC();
		  x.go(); //implement function go 
		  
   
	 
	
	
	}
	
	
	
	public void go(){ //for implementation of window(s)
		 
		
		//main menu
		
		//create buttons
		f = new JFrame("Bank Menu");
		j = new Button("Create Account");
		g =new Button("Deposit Money");
		h= new Button("Withdraw");
		i= new Button("Bank Statement");
		
		GridLayout FL = new GridLayout(4,1);
		 
		f.setLayout(FL);
		
		
		// add buttons onto grid 
		f.add(j);
		f.add(g);
		f.add(h);
		f.add(i);
		 
		//when we press exit, on main menu, all frame close
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 
		f.setSize(300,500);
		f.setVisible(true);
		
		//implement button actions
		j.addActionListener(this);
		g.addActionListener(this);
		h.addActionListener(this);
		i.addActionListener(this);
		
		}
	
	public void actionPerformed(ActionEvent e){
		
			//when we fill out the corresponding fields and click on buttons, it will do:
			
				
			
				
				Connection conn = null;
				Statement stmt = null;
				
				
				try { //for create accounts
					Class.forName("com.mysql.jdbc.Driver");
					conn=DriverManager.getConnection("jdbc:mysql://localhost/qac","root","");
					stmt=conn.createStatement();
					
					//insert what's be put into fields onto SQL database
					PreparedStatement pstmt = conn.prepareStatement("insert into accounts (Names,Address) values('"+T1.getText()+"','"+T2.getText()+"')");
					
					// can use executeQuery or executeUpdate, first one is for searching second for inserting
					
					String sql = "SELECT * FROM accounts;"; //from accounts table
					ResultSet rs = stmt.executeQuery(sql); //look up
					while(rs.next()){ //rs.next returns true or false, once it has finished looking at the files it returns false and loop closes
						String acc=rs.getString(2); //get account number assigned to new account
						if (rs.next()== false) {
						System.out.println("Account number inputted: " +acc); //user sees what account number he has
						}
						
					}
					pstmt.executeLargeUpdate(); //update database
					
					
					}
					
				
				catch(ClassNotFoundException se1) { //catch exceptions if found
					se1.printStackTrace(); 

					}
				
				catch(SQLException se1) {
					se1.printStackTrace(); 

					}
				catch (Exception e1)
				{
					
				}
				
				
				try {// for deposit
					Class.forName("com.mysql.jdbc.Driver");
					conn=DriverManager.getConnection("jdbc:mysql://localhost/qac","root","");
					stmt=conn.createStatement();
					String Acno=T4.getText();
					PreparedStatement pstmt = conn.prepareStatement("insert into deposit (AccountNumber, Amount,Date) values('"+Acno+"','"+T5.getText()+"','"+T6.getText()+"')");
					// can use executeQuery or executeUpdate, first one is for searching second for inserting
					String sq2 = "SELECT * FROM accounts where AccountNumber="+Acno;
					ResultSet rs1 = stmt.executeQuery(sq2);
					if(rs1.next()){
							pstmt.executeLargeUpdate();
						}
						else {
							System.out.println("Account number does not exist");
						}
						
					}
					
				
					
										
				
				catch(ClassNotFoundException se1) {
					se1.printStackTrace(); 

					}
				
				catch(SQLException se1) {
					se1.printStackTrace(); 

					}
				catch (Exception e1)
				{
					
				}
				
				
				try {// for withdraw
					Class.forName("com.mysql.jdbc.Driver");
					conn=DriverManager.getConnection("jdbc:mysql://localhost/qac","root","");
					stmt=conn.createStatement();
					String Acno1=T7.getText();
					String Amountgive=T8.getText();
					PreparedStatement pstmt = conn.prepareStatement("insert into withdraw (AccountNumber, Amount,Date) values('"+Acno1+"','"+Amountgive+"','"+T9.getText()+"')");
					// can use executeQuery or executeUpdate, first one is for searching second for inserting
					String sq3 = "SELECT * FROM accounts where AccountNumber=" +Acno1;
					ResultSet rs2 = stmt.executeQuery(sq3);
						
					// used when user tries to withdraw more than has, therefore must calculate total balance
					int totalWithdraw=0;
					int totalDeposits=0;
					int total=0;
							
					if(rs2.next()){
						
						
						String sqd = "SELECT * FROM deposit" ;
						ResultSet rsd = stmt.executeQuery(sqd);
						
						while(rsd.next()){ //total deposits
							int currentIDdep= rsd.getInt("AccountNumber");
							if (Integer.parseInt(Acno1)==currentIDdep) {
								totalDeposits+=rsd.getInt("Amount");
							}
						}
						
						String sqw = "SELECT * FROM withdraw " ;
						ResultSet rsw = stmt.executeQuery(sqw);
						
						
						
						while(rsw.next()) { //total withdraws
						
						int currentIDwith= rsw.getInt("AccountNumber");
						if (Integer.parseInt(Acno1)==currentIDwith) {
							totalWithdraw+=rsw.getInt("Amount");
							
							
							
						}
						
					}
						
						
						System.out.println("totalWith: " +totalWithdraw);
						System.out.println("totalDep:" +totalDeposits);
						total=totalDeposits-totalWithdraw; //total balance
						System.out.println("total:" +total);
					
					
						int intAmount=Integer.parseInt(Amountgive);
						if (total>=intAmount) { //if total balance more than current withdraw, update
							pstmt.executeLargeUpdate();
						}
						else {
							System.out.println("Not enough money to withdraw, you have " +total + " in bank account");
						}
					
					}
						
					else {
						System.out.println("Account number does not exist");
					}
					
				
					
					}
					
				
				catch(ClassNotFoundException se1) {
					se1.printStackTrace(); 

					}
				
				catch(SQLException se1) {
					se1.printStackTrace(); 

					}
				catch (Exception e1)
				{
					
				}
		
		
				try {// for bank statement
					Class.forName("com.mysql.jdbc.Driver");
					conn=DriverManager.getConnection("jdbc:mysql://localhost/qac","root","");
					stmt=conn.createStatement();
					String Acno2=T10.getText();
					
					// can use executeQuery or executeUpdate, first one is for searching second for inserting
					String sq4 = "SELECT * FROM accounts where AccountNumber=" +Acno2;
					ResultSet rs3 = stmt.executeQuery(sq4);
					
					
					int totalWithdraw2=0;
					int totalDeposits2=0;					
					int total2=0;
					String Date1=null;
					String Date2=null;
					
					
					if(rs3.next()){ //similar as before from total balance but want to print out every withdraw and deposit and when
						System.out.println("Account number does exist");
						String sqd = "SELECT * FROM deposit" ;
						ResultSet rsd = stmt.executeQuery(sqd);
						
						while(rsd.next()){
							int currentIDdep= rsd.getInt("AccountNumber");
							if (Integer.parseInt(Acno2)==currentIDdep) {
								totalDeposits2+=rsd.getInt("Amount");
								Date1=rsd.getString("Date");
								System.out.println("   Date: " + Date1);
								System.out.print("Deposit: "  + "+"+totalDeposits2);
								
							}
						}
						
						String sqw = "SELECT * FROM withdraw " ;
						ResultSet rsw = stmt.executeQuery(sqw);
						
						
						
						while(rsw.next()) {
						
						int currentIDwith= rsw.getInt("AccountNumber");
						if (Integer.parseInt(Acno2)==currentIDwith) {
							totalWithdraw2+=rsw.getInt("Amount");
							Date2=rsw.getString("Date");
							System.out.println("   Date: " + Date2);
							System.out.print("Withdraw: " + "-" +totalWithdraw2);
							
							
							
						}
						
					}
						
						
						
						total2=totalDeposits2-totalWithdraw2;
						System.out.println(" \n total:" +total2);
					
					
						
						
						
					}
					else {
						System.out.println("Account number does not exist");
					}
					
				
					
					}
					
				
				catch(ClassNotFoundException se1) {
					se1.printStackTrace(); 

					}
				
				catch(SQLException se1) {
					se1.printStackTrace(); 

					}
				catch (Exception e1)
				{
					
				}
		
				
				
		
		// whatever buton is clicked in main menu will take you onto another frame		
		Button Btn; 
		Btn=(Button) e.getSource();
		String TitleBtn = Btn.getLabel();
		 
		 
		
		 
		if (TitleBtn.equals("Create Account")) {
			//create account page
				f1 = new JFrame();
				k = new Button("Okay");
				T1= new JTextField();
				T2= new JTextField();
				//T3= new JTextField(); //don't need user to input as database auto-increments and returns an account number to the user
				 
				L1= new Label("Name:  ");
				L2= new Label("Address:  ");
				//L3= new Label("Account Number:  ");
				
				GridLayout FL1 = new GridLayout(3,1);
				
				f1.setLayout(FL1);
				
				
				f1.add(L1);
				f1.add(T1);
				f1.add(L2);
				f1.add(T2);
				//f1.add(L3);
				//f1.add(T3);
				f1.add(k);
				
				
				f1.setSize(300,300);
				f1.setVisible(true);
				k.addActionListener(this); //work okay button
		}
		 
		 
		if (TitleBtn.equals("Deposit Money")) {
			
			//Deposit Money Page
				f2 = new JFrame();
				k1 = new Button("Okay");
				T4= new JTextField();
				T5= new JTextField();
				T6= new JTextField();
				 
				L4= new Label("Account Number:  ");
				L5= new Label("Amount:  ");
				L6= new Label("Date:  ");
				
				GridLayout FL2 = new GridLayout(4,1);
				
				f2.setLayout(FL2);
				
				
				f2.add(L4);
				f2.add(T4);
				f2.add(L5);
				f2.add(T5);
				f2.add(L6);
				f2.add(T6);
				f2.add(k1);
				
				
				f2.setSize(300,300); //if we do this all windows pop up!!
				f2.setVisible(true);
				k1.addActionListener(this);
		}
		 
		if (TitleBtn.equals("Withdraw")) {
			//Withdraw Money Page
				f3 = new JFrame();
				k2 = new Button("Okay");
				T7= new JTextField();
			    T8= new JTextField();
				T9= new JTextField();
						 
			    L7= new Label("Account Number:  ");
				L8= new Label("Amount:  ");
				L9= new Label("Date:  ");
						
			    GridLayout FL3 = new GridLayout(4,1);
						
				f3.setLayout(FL3);
						
						
				f3.add(L7);
				f3.add(T7);
				f3.add(L8);
				f3.add(T8);
				f3.add(L9);
				f3.add(T9);
				f3.add(k2);
				
				f3.setSize(300,300); //if we do this all windows pop up!!
				f3.setVisible(true);
				k2.addActionListener(this);
			  
		}
		 
		if (TitleBtn.equals("Bank Statement")) {
			//bank account page
				f4 = new JFrame();
				k4 = new Button("Retrieve");
				T10= new JTextField();
			    
				
				L10= new Label("Account Num:  ");
				
				
				GridLayout FL4 = new GridLayout(2,1);
				
				f4.setLayout(FL4);
				 
				f4.add(L10);
				f4.add(T10);
				f4.add(k4);
				
				f4.setSize(300,300); //if we do this all windows pop up!!
				f4.setVisible(true);
				k4.addActionListener(this);

			  
		}
		
		
		}
	
}

